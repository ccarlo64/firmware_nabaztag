#ifndef MY_SIMUNET_H_
# define MY_SIMUNET_H_

int simunetinit();
int checkNetworkEvents();

#endif // ! MY_SIMUNET_H_
