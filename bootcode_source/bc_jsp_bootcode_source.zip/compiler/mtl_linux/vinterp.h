// VLISP Virtual Machine - 2006 - by Sylvain Huet
// Lowcost IS Powerfull

#ifndef _INTERPRETER_
#define _INTERPRETER_

void interpGo();

#include"vbc.h"
#endif

