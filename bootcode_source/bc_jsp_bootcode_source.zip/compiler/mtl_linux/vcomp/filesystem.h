//-------------------
// Moteur 3d
// version WIN32 et POCKETPC
// Sylvain Huet
// Premiere version : 03/09/2002
// Derniere mise a jour : 05/10/2002
//



#ifndef _FILESYSTEM_
#define _FILESYSTEM_
class FileSystem;
#endif
