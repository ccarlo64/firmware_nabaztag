#include "TypeString.h"

string TypeString::toString() {
	return "STRING";
}
