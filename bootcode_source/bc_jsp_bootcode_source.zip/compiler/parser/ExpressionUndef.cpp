#include "ExpressionUndef.h"

string ExpressionUndef::toString(void) {
	return "_";
}
