#ifndef __VM_FUNCTIONS__
#define __VM_FUNCTIONS__

#include "Debug.h"
#include "Program.h"
#include "TypeTable.h"

using namespace std;

class VMFunctions {
public:
	static void addVMFunctionsToProgram(); 
};

#endif
