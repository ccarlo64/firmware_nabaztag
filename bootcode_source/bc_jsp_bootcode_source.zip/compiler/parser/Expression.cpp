#include "Expression.h"

Type* Expression::getType() {
	return type;
}

void Expression::setType(Type *td) {
	type = td;
}
