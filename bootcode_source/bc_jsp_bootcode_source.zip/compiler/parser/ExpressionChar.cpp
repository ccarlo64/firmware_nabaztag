#include "ExpressionChar.h"

string ExpressionChar::toString() {
	return this->value;
}

string ExpressionChar::getValue() {
	return this->value;
}
