#include "TypeInt.h"

string TypeInt::toString() {
	return "INT";
}
