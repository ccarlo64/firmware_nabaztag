#include "ExpressionNil.h"

string ExpressionNil::toString() {
	return "nil";
}
